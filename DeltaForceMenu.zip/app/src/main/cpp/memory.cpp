#include "memory.h"
#include <fcntl.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sys/uio.h>
#include <errno.h>

static pid_t g_pid = -1;
static int g_mem_fd = -1;

bool open_process(pid_t pid) {
    close_process();
    g_pid = pid;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);
    g_mem_fd = open(path, O_RDWR);
    // process_vm_readv works even if mem fd fails on some kernels
    return g_pid > 0;
}

void close_process() {
    if (g_mem_fd >= 0) {
        close(g_mem_fd);
        g_mem_fd = -1;
    }
    g_pid = -1;
}

bool is_process_open() {
    return g_pid > 0;
}

pid_t get_pid() {
    return g_pid;
}

bool read_mem(uintptr_t addr, void* buf, size_t size) {
    if (g_pid <= 0) return false;

    // prefer process_vm_readv (no /proc/mem needed, works on many devices)
    struct iovec local{ buf, size };
    struct iovec remote{ reinterpret_cast<void*>(addr), size };
    ssize_t n = process_vm_readv(g_pid, &local, 1, &remote, 1, 0);
    if (n == (ssize_t)size) return true;

    // fallback /proc/pid/mem
    if (g_mem_fd >= 0) {
        if (lseek(g_mem_fd, (off_t)addr, SEEK_SET) == (off_t)-1) return false;
        ssize_t r = read(g_mem_fd, buf, size);
        return r == (ssize_t)size;
    }
    return false;
}

bool write_mem(uintptr_t addr, const void* buf, size_t size) {
    if (g_pid <= 0) return false;

    struct iovec local{ const_cast<void*>(buf), size };
    struct iovec remote{ reinterpret_cast<void*>(addr), size };
    ssize_t n = process_vm_writev(g_pid, &local, 1, &remote, 1, 0);
    if (n == (ssize_t)size) return true;

    if (g_mem_fd >= 0) {
        if (lseek(g_mem_fd, (off_t)addr, SEEK_SET) == (off_t)-1) return false;
        ssize_t w = write(g_mem_fd, buf, size);
        return w == (ssize_t)size;
    }
    return false;
}

std::vector<MemRegion> parse_maps() {
    std::vector<MemRegion> out;
    if (g_pid <= 0) return out;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", g_pid);
    FILE* f = fopen(path, "r");
    if (!f) return out;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uintptr_t start = 0, end = 0;
        char perms[8] = {};
        char mapname[256] = {};
        int n = sscanf(line, "%lx-%lx %7s %*s %*s %*s %255s",
                       &start, &end, perms, mapname);
        if (n < 3) continue;
        MemRegion r;
        r.start = start;
        r.end = end;
        r.r = perms[0] == 'r';
        r.w = perms[1] == 'w';
        r.x = perms[2] == 'x';
        r.path = (n >= 4) ? mapname : "";
        out.push_back(r);
    }
    fclose(f);
    return out;
}

uintptr_t find_module_base(const char* name) {
    auto maps = parse_maps();
    for (auto& m : maps) {
        if (m.path.find(name) != std::string::npos) {
            return m.start;
        }
    }
    return 0;
}

uintptr_t find_pattern(uintptr_t start, uintptr_t end, const uint8_t* pat, const char* mask) {
    size_t len = strlen(mask);
    if (end <= start || len == 0) return 0;
    const size_t chunk = 0x10000;
    std::vector<uint8_t> buf(chunk + len);
    for (uintptr_t addr = start; addr < end; addr += chunk) {
        size_t to_read = chunk + len;
        if (addr + to_read > end) to_read = end - addr;
        if (!read_mem(addr, buf.data(), to_read)) continue;
        for (size_t i = 0; i + len <= to_read; i++) {
            bool ok = true;
            for (size_t j = 0; j < len; j++) {
                if (mask[j] == 'x' && buf[i + j] != pat[j]) {
                    ok = false;
                    break;
                }
            }
            if (ok) return addr + i;
        }
    }
    return 0;
}
