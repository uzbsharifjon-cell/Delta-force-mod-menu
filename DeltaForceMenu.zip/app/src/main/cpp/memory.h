#pragma once
#include <cstdint>
#include <sys/types.h>
#include <vector>
#include <string>

struct MemRegion {
    uintptr_t start;
    uintptr_t end;
    bool r, w, x;
    std::string path;
};

bool open_process(pid_t pid);
void close_process();
bool is_process_open();
pid_t get_pid();

bool read_mem(uintptr_t addr, void* buf, size_t size);
bool write_mem(uintptr_t addr, const void* buf, size_t size);

template<typename T>
bool read_t(uintptr_t addr, T& out) {
    return read_mem(addr, &out, sizeof(T));
}

template<typename T>
bool write_t(uintptr_t addr, const T& val) {
    return write_mem(addr, &val, sizeof(T));
}

std::vector<MemRegion> parse_maps();
uintptr_t find_module_base(const char* name);
uintptr_t find_pattern(uintptr_t start, uintptr_t end, const uint8_t* pat, const char* mask);
