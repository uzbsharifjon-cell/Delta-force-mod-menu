#include <jni.h>
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <vector>
#include <mutex>
#include <atomic>
#include <thread>
#include <chrono>

#include "process.h"
#include "memory.h"

#define LOG_TAG "dfinject"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/*
 * External injector core.
 *
 * Strategy:
 *  1. Find game PID by package name
 *  2. Open process via process_vm_readv /proc/pid/mem
 *  3. Locate main module base (libil2cpp.so / libUE4.so / etc)
 *  4. Resolve entity list via pattern or known offsets (user-configurable)
 *  5. Project world->screen and fill JNI float buffers
 *
 * Offsets below are placeholders — update via GameOffsets structure
 * after dumping with Il2CppDumper / UnrealDumper / CE.
 */

struct GameOffsets {
    // set these after reverse engineering the specific build
    uintptr_t module_base = 0;
    uintptr_t gworld_rva = 0;          // GWorld / UWorld*
    uintptr_t persistent_level = 0x30; // example
    uintptr_t actor_array = 0x98;      // example
    uintptr_t actor_count = 0xA0;
    uintptr_t root_component = 0x1C0;
    uintptr_t relative_location = 0x11C;
    uintptr_t health = 0x0;            // fill per game
    uintptr_t max_health = 0x0;
    uintptr_t team_id = 0x0;
    uintptr_t player_controller = 0x0;
    uintptr_t camera_manager = 0x0;
    uintptr_t camera_cache = 0x0;
    bool valid = false;
};

static std::mutex g_mtx;
static GameOffsets g_off;
static std::atomic<bool> g_attached{false};
static pid_t g_game_pid = -1;
static char g_pkg[128] = {};

// simple camera for projection (filled when offsets known)
struct FVector { float x, y, z; };
struct FRotator { float pitch, yaw, roll; };
struct MinimalViewInfo {
    FVector location;
    FRotator rotation;
    float fov;
};

static MinimalViewInfo g_cam{};
static int g_screen_w = 1080;
static int g_screen_h = 1920;

static bool world_to_screen(const FVector& world, float& sx, float& sy) {
    // basic UE-style W2S (simplified)
    float radPitch = g_cam.rotation.pitch * (float)M_PI / 180.f;
    float radYaw   = g_cam.rotation.yaw   * (float)M_PI / 180.f;
    float radRoll  = g_cam.rotation.roll  * (float)M_PI / 180.f;

    float SP = sinf(radPitch), CP = cosf(radPitch);
    float SY = sinf(radYaw),   CY = cosf(radYaw);
    float SR = sinf(radRoll),  CR = cosf(radRoll);

    FVector axisX{ CP * CY, CP * SY, SP };
    FVector axisY{ SR * SP * CY - CR * SY, SR * SP * SY + CR * CY, -SR * CP };
    FVector axisZ{ -(CR * SP * CY + SR * SY), CY * SR - CR * SP * SY, CR * CP };

    FVector delta{
        world.x - g_cam.location.x,
        world.y - g_cam.location.y,
        world.z - g_cam.location.z
    };

    FVector transformed{
        delta.x * axisY.x + delta.y * axisY.y + delta.z * axisY.z,
        delta.x * axisZ.x + delta.y * axisZ.y + delta.z * axisZ.z,
        delta.x * axisX.x + delta.y * axisX.y + delta.z * axisX.z
    };

    if (transformed.z < 1.f) return false;

    float fovRad = g_cam.fov * (float)M_PI / 180.f;
    float screenCenterX = g_screen_w / 2.f;
    float screenCenterY = g_screen_h / 2.f;

    sx = screenCenterX + transformed.x * (screenCenterX / tanf(fovRad / 2.f)) / transformed.z;
    sy = screenCenterY - transformed.y * (screenCenterX / tanf(fovRad / 2.f)) / transformed.z;
    return sx >= -50 && sx <= g_screen_w + 50 && sy >= -50 && sy <= g_screen_h + 50;
}

// ---- demo entity generator when real offsets not set ----
struct DemoEntity {
    float x, y, w, h, hp, armor, dist;
    int flags;
};
static std::vector<DemoEntity> g_demo;
static std::vector<DemoEntity> g_demo_loot;
static uint64_t g_tick = 0;

static void update_demo() {
    g_tick++;
    if (g_demo.empty()) {
        for (int i = 0; i < 7; i++) {
            DemoEntity e{};
            e.x = 100 + (i * 140) % 800;
            e.y = 200 + (i * 90) % 600;
            e.w = 70 + (i % 3) * 15;
            e.h = 140 + (i % 4) * 20;
            e.hp = 35 + (i * 11) % 65;
            e.armor = i % 6;
            e.dist = 20 + i * 17;
            e.flags = 3;
            g_demo.push_back(e);
        }
        for (int i = 0; i < 10; i++) {
            DemoEntity l{};
            l.x = 50 + (i * 97) % 900;
            l.y = 150 + (i * 73) % 700;
            l.w = (float)(1 + i % 6); // tier
            l.h = (float)(i % 5);     // type
            l.flags = 1;
            g_demo_loot.push_back(l);
        }
    }
    for (auto& e : g_demo) {
        e.x += sinf((g_tick + e.dist) * 0.03f) * 1.5f;
        e.y += cosf((g_tick + e.hp) * 0.025f) * 1.1f;
        if (e.x < 30) e.x = 30;
        if (e.x > g_screen_w - 100) e.x = g_screen_w - 100.f;
        if (e.y < 80) e.y = 80;
        if (e.y > g_screen_h - 200) e.y = g_screen_h - 200.f;
    }
}

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_deltaforce_menu_NativeBridge_nativeAttach(JNIEnv* env, jclass, jstring jpkg) {
    const char* pkg = env->GetStringUTFChars(jpkg, nullptr);
    if (!pkg) return JNI_FALSE;

    std::lock_guard<std::mutex> lock(g_mtx);
    strncpy(g_pkg, pkg, sizeof(g_pkg) - 1);
    env->ReleaseStringUTFChars(jpkg, pkg);

    pid_t pid = find_pid_by_package(g_pkg);
    if (pid <= 0) {
        // try common delta force package names
        const char* alts[] = {
            "com.proxima.dfm",
            "com.garena.game.df",
            "com.tencent.tmgp.dfm",
            "com.levelinfinite.dfm",
            nullptr
        };
        for (int i = 0; alts[i]; i++) {
            pid = find_pid_by_package(alts[i]);
            if (pid > 0) {
                strncpy(g_pkg, alts[i], sizeof(g_pkg) - 1);
                break;
            }
        }
    }

    if (pid <= 0) {
        LOGI("game process not found, running in demo mode");
        g_game_pid = -1;
        g_attached = true; // demo mode still "attached"
        g_off.valid = false;
        return JNI_TRUE;
    }

    if (!open_process(pid)) {
        LOGE("open_process failed for pid %d", pid);
        g_attached = false;
        return JNI_FALSE;
    }

    g_game_pid = pid;
    g_attached = true;
    g_off.valid = false;

    // try locate unity / unreal module
    uintptr_t base = find_module_base("libil2cpp.so");
    if (!base) base = find_module_base("libUE4.so");
    if (!base) base = find_module_base("libunity.so");
    g_off.module_base = base;

    LOGI("attached pid=%d pkg=%s base=0x%lx", pid, g_pkg, (unsigned long)base);
    // offsets stay invalid until user fills them — ESP falls back to demo
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_deltaforce_menu_NativeBridge_nativeDetach(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(g_mtx);
    close_process();
    g_game_pid = -1;
    g_attached = false;
    g_off.valid = false;
    g_demo.clear();
    g_demo_loot.clear();
    LOGI("detached");
}

JNIEXPORT jint JNICALL
Java_com_deltaforce_menu_NativeBridge_nativeReadEntities(JNIEnv* env, jclass, jfloatArray jout, jint maxCount) {
    if (!g_attached.load()) return 0;
    if (maxCount <= 0) return 0;

    std::lock_guard<std::mutex> lock(g_mtx);

    // real path when offsets configured
    if (g_off.valid && g_game_pid > 0 && is_process_alive(g_game_pid)) {
        // placeholder: user fills pointer chain after dump
        // example skeleton:
        // uintptr_t uworld = 0;
        // read_t(g_off.module_base + g_off.gworld_rva, uworld);
        // ... walk actor array, project, fill buffer
        // for now fall through to demo so overlay always shows something
    }

    update_demo();
    int count = (int)std::min((size_t)maxCount, g_demo.size());
    if (count <= 0) return 0;

    jfloat* buf = env->GetFloatArrayElements(jout, nullptr);
    if (!buf) return 0;

    for (int i = 0; i < count; i++) {
        const auto& e = g_demo[i];
        int o = i * 8;
        buf[o + 0] = e.x;
        buf[o + 1] = e.y;
        buf[o + 2] = e.w;
        buf[o + 3] = e.h;
        buf[o + 4] = e.hp;
        buf[o + 5] = (float)e.armor;
        buf[o + 6] = e.dist;
        buf[o + 7] = (float)e.flags;
    }

    env->ReleaseFloatArrayElements(jout, buf, 0);
    return count;
}

JNIEXPORT jint JNICALL
Java_com_deltaforce_menu_NativeBridge_nativeReadLoot(JNIEnv* env, jclass, jfloatArray jout, jint maxCount) {
    if (!g_attached.load()) return 0;
    if (maxCount <= 0) return 0;

    std::lock_guard<std::mutex> lock(g_mtx);
    update_demo();

    int count = (int)std::min((size_t)maxCount, g_demo_loot.size());
    if (count <= 0) return 0;

    jfloat* buf = env->GetFloatArrayElements(jout, nullptr);
    if (!buf) return 0;

    for (int i = 0; i < count; i++) {
        const auto& l = g_demo_loot[i];
        int o = i * 6;
        buf[o + 0] = l.x;
        buf[o + 1] = l.y;
        buf[o + 2] = l.w; // tier
        buf[o + 3] = l.h; // type
        buf[o + 4] = 0;
        buf[o + 5] = (float)l.flags;
    }

    env->ReleaseFloatArrayElements(jout, buf, 0);
    return count;
}

} // extern C
