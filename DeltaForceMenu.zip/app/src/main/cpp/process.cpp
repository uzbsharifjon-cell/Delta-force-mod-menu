#include "process.h"
#include <dirent.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <cctype>

static bool is_digits(const char* s) {
    if (!s || !*s) return false;
    for (; *s; s++) if (!isdigit((unsigned char)*s)) return false;
    return true;
}

std::vector<ProcInfo> list_processes() {
    std::vector<ProcInfo> out;
    DIR* d = opendir("/proc");
    if (!d) return out;
    struct dirent* de;
    while ((de = readdir(d)) != nullptr) {
        if (!is_digits(de->d_name)) continue;
        pid_t pid = (pid_t)atoi(de->d_name);
        char path[64];
        snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
        FILE* f = fopen(path, "r");
        if (!f) continue;
        char cmd[256] = {};
        size_t n = fread(cmd, 1, sizeof(cmd) - 1, f);
        fclose(f);
        if (n == 0) continue;
        // cmdline is null-separated
        for (size_t i = 0; i < n; i++) if (cmd[i] == '\0') cmd[i] = ' ';
        ProcInfo info;
        info.pid = pid;
        info.cmdline = cmd;
        // basename-ish
        const char* slash = strrchr(cmd, '/');
        info.name = slash ? (slash + 1) : cmd;
        out.push_back(info);
    }
    closedir(d);
    return out;
}

pid_t find_pid_by_package(const char* packageName) {
    if (!packageName || !*packageName) return -1;
    auto procs = list_processes();
    for (auto& p : procs) {
        // exact package or package:something (android multi-process)
        if (p.cmdline == packageName) return p.pid;
        if (p.cmdline.find(packageName) == 0) {
            size_t len = strlen(packageName);
            if (p.cmdline.size() == len || p.cmdline[len] == ':' || p.cmdline[len] == ' ')
                return p.pid;
        }
    }
    return -1;
}

bool is_process_alive(pid_t pid) {
    if (pid <= 0) return false;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d", pid);
    return access(path, F_OK) == 0;
}
