#pragma once
#include <sys/types.h>
#include <string>
#include <vector>

struct ProcInfo {
    pid_t pid;
    std::string name;
    std::string cmdline;
};

std::vector<ProcInfo> list_processes();
pid_t find_pid_by_package(const char* packageName);
bool is_process_alive(pid_t pid);
