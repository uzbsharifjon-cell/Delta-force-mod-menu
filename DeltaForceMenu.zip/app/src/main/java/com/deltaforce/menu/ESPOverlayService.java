package com.deltaforce.menu;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public class ESPOverlayService extends Service {

    private WindowManager windowManager;
    private ESPCanvasView canvasView;
    private WindowManager.LayoutParams params;
    private Handler handler;
    private Runnable drawLoop;
    private SharedPreferences prefs;
    private boolean running = false;

    public static final String ACTION_UPDATE = "com.deltaforce.menu.ESP_UPDATE";
    public static final String ACTION_ATTACH = "com.deltaforce.menu.ESP_ATTACH";
    public static final String EXTRA_PACKAGE = "package";

    private static final String[] GAME_PACKAGES = {
            "com.proxima.dfm",
            "com.garena.game.df",
            "com.tencent.tmgp.dfm",
            "com.levelinfinite.dfm"
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("DeltaForceMenuPrefs", Context.MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;

        canvasView = new ESPCanvasView(this);
        try {
            windowManager.addView(canvasView, params);
        } catch (Exception e) {
            stopSelf();
            return;
        }

        // try attach injector
        tryAttach();

        handler = new Handler(Looper.getMainLooper());
        drawLoop = new Runnable() {
            @Override
            public void run() {
                if (running) {
                    canvasView.invalidate();
                    handler.postDelayed(this, 16); // ~60fps
                }
            }
        };
        running = true;
        handler.post(drawLoop);
    }

    private void tryAttach() {
        if (!NativeBridge.isNativeLoaded()) return;
        if (NativeBridge.isAttached()) return;
        for (String pkg : GAME_PACKAGES) {
            if (NativeBridge.attach(pkg)) return;
        }
        // still enable demo mode
        NativeBridge.attach(GAME_PACKAGES[0]);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_UPDATE.equals(action)) {
                if (canvasView != null) canvasView.refreshPrefs();
            } else if (ACTION_ATTACH.equals(action)) {
                String pkg = intent.getStringExtra(EXTRA_PACKAGE);
                if (pkg != null && NativeBridge.isNativeLoaded()) {
                    NativeBridge.detach();
                    NativeBridge.attach(pkg);
                } else {
                    tryAttach();
                }
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (handler != null) handler.removeCallbacks(drawLoop);
        NativeBridge.detach();
        if (canvasView != null && windowManager != null) {
            try {
                windowManager.removeView(canvasView);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    private class ESPCanvasView extends View {
        private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint healthPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint lootPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint statusPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final float[] entityBuf = new float[64 * 8]; // 64 entities
        private final float[] lootBuf = new float[64 * 6];

        private boolean espMain, espArmor, espHealth, espDistance, espWeapon;
        private boolean lootMain;
        private final boolean[] tiers = new boolean[7];

        private static final int[] TIER_COLORS = {
                0, 0xFFA0A0A0, 0xFF4CAF50, 0xFF2196F3,
                0xFF9C27B0, 0xFFFF9800, 0xFFF44336
        };
        private static final String[] WEAPONS = {
                "M4A1", "AK-47", "MP5", "AWM", "Vector", "SCAR-L", "Groza"
        };

        ESPCanvasView(Context ctx) {
            super(ctx);
            boxPaint.setStyle(Paint.Style.STROKE);
            boxPaint.setStrokeWidth(2.5f);
            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(26f);
            textPaint.setShadowLayer(2, 1, 1, Color.BLACK);
            healthPaint.setStyle(Paint.Style.FILL);
            lootPaint.setStyle(Paint.Style.STROKE);
            lootPaint.setStrokeWidth(2f);
            statusPaint.setColor(0xAA00B4FF);
            statusPaint.setTextSize(22f);
            statusPaint.setShadowLayer(2, 1, 1, Color.BLACK);
            refreshPrefs();
        }

        void refreshPrefs() {
            espMain = prefs.getBoolean("esp_main", false);
            espArmor = prefs.getBoolean("esp_armor", true);
            espHealth = prefs.getBoolean("esp_health", true);
            espDistance = prefs.getBoolean("esp_distance", true);
            espWeapon = prefs.getBoolean("esp_weapon", true);
            lootMain = prefs.getBoolean("loot_main", false);
            for (int i = 1; i <= 6; i++) {
                tiers[i] = prefs.getBoolean("tier" + i, false);
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (!espMain && !lootMain) {
                // still show injector status corner
                drawStatus(canvas);
                return;
            }

            int entCount = 0;
            int lootCount = 0;
            if (NativeBridge.isNativeLoaded()) {
                entCount = NativeBridge.readEntities(entityBuf, 64);
                lootCount = NativeBridge.readLoot(lootBuf, 64);
            }

            if (espMain && entCount > 0) {
                for (int i = 0; i < entCount; i++) {
                    int o = i * 8;
                    float x = entityBuf[o];
                    float y = entityBuf[o + 1];
                    float w = entityBuf[o + 2];
                    float h = entityBuf[o + 3];
                    float hp = entityBuf[o + 4];
                    float armor = entityBuf[o + 5];
                    float dist = entityBuf[o + 6];
                    // float flags = entityBuf[o + 7];

                    int color = hp > 60 ? Color.GREEN : (hp > 30 ? Color.YELLOW : Color.RED);
                    boxPaint.setColor(color);
                    canvas.drawRect(new RectF(x, y, x + w, y + h), boxPaint);

                    float ty = y - 6;
                    if (espDistance) {
                        canvas.drawText(((int) dist) + "m", x, ty, textPaint);
                        ty -= 28;
                    }
                    if (espWeapon) {
                        int wi = ((int) dist) % WEAPONS.length;
                        canvas.drawText(WEAPONS[wi], x, ty, textPaint);
                        ty -= 28;
                    }
                    if (espArmor && armor > 0) {
                        canvas.drawText("Armor " + (int) armor, x, ty, textPaint);
                    }
                    if (espHealth) {
                        float barH = 5f;
                        healthPaint.setColor(0x88000000);
                        canvas.drawRect(x, y + h + 3, x + w, y + h + 3 + barH, healthPaint);
                        healthPaint.setColor(color);
                        float ratio = Math.max(0f, Math.min(1f, hp / 100f));
                        canvas.drawRect(x, y + h + 3, x + w * ratio, y + h + 3 + barH, healthPaint);
                    }
                }
            }

            if (lootMain && lootCount > 0) {
                for (int i = 0; i < lootCount; i++) {
                    int o = i * 6;
                    float x = lootBuf[o];
                    float y = lootBuf[o + 1];
                    int tier = (int) lootBuf[o + 2];
                    if (tier < 1 || tier > 6 || !tiers[tier]) continue;
                    lootPaint.setColor(TIER_COLORS[tier]);
                    float s = 16f;
                    canvas.drawRect(x - s, y - s, x + s, y + s, lootPaint);
                    textPaint.setColor(TIER_COLORS[tier]);
                    canvas.drawText("T" + tier, x + s + 4, y + 6, textPaint);
                    textPaint.setColor(Color.WHITE);
                }
            }

            drawStatus(canvas);
        }

        private void drawStatus(Canvas canvas) {
            String st = NativeBridge.getStatus();
            String line = "injector: " + st
                    + (NativeBridge.isNativeLoaded() ? " | native" : " | java-fallback");
            canvas.drawText(line, 20, 40, statusPaint);
        }
    }
}
