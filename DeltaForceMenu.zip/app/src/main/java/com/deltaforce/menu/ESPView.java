package com.deltaforce.menu;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class ESPView extends View {

    private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ESPView(Context context) {
        super(context);
        init();
    }

    public ESPView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(3f);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(26f);
        textPaint.setShadowLayer(2, 1, 1, Color.BLACK);
        barPaint.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // demo player 1
        boxPaint.setColor(Color.GREEN);
        canvas.drawRect(40, 30, 130, 210, boxPaint);
        canvas.drawText("42m", 40, 26, textPaint);
        canvas.drawText("M4A1", 40, 230, textPaint);
        barPaint.setColor(0x88000000);
        canvas.drawRect(40, 214, 130, 222, barPaint);
        barPaint.setColor(Color.GREEN);
        canvas.drawRect(40, 214, 110, 222, barPaint);

        // demo player 2
        boxPaint.setColor(Color.YELLOW);
        canvas.drawRect(170, 55, 255, 230, boxPaint);
        canvas.drawText("87m", 170, 50, textPaint);
        canvas.drawText("AK-47", 170, 250, textPaint);
        barPaint.setColor(0x88000000);
        canvas.drawRect(170, 234, 255, 242, barPaint);
        barPaint.setColor(Color.YELLOW);
        canvas.drawRect(170, 234, 210, 242, barPaint);

        // loot marker
        boxPaint.setColor(0xFFFF9800);
        canvas.drawRect(120, 140, 150, 170, boxPaint);
        canvas.drawText("T5 Vest", 155, 160, textPaint);
    }
}
