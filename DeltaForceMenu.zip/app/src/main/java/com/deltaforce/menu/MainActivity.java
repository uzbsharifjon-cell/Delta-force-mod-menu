package com.deltaforce.menu;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String[] GAME_PACKAGES = {
            "com.proxima.dfm",
            "com.garena.game.df",
            "com.tencent.tmgp.dfm"
    };
    private static final int OVERLAY_PERMISSION_REQUEST = 1001;

    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        Button btnLaunch = findViewById(R.id.btnLaunchGame);
        Button btnShowMenu = findViewById(R.id.btnShowMenu);
        Button btnGuide = findViewById(R.id.btnGuide);

        refreshStatus();

        btnLaunch.setOnClickListener(v -> launchGame());
        btnShowMenu.setOnClickListener(v -> {
            if (checkOverlayPermission()) {
                startFloatingMenu();
            } else {
                requestOverlayPermission();
            }
        });
        if (btnGuide != null) {
            btnGuide.setOnClickListener(v -> showGuide());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        if (statusText == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("overlay: ").append(checkOverlayPermission() ? "OK" : "KERAK").append("\n");
        sb.append("native: ").append(NativeBridge.isNativeLoaded() ? "loaded" : "yo'q").append("\n");
        sb.append("injector: ").append(NativeBridge.getStatus()).append("\n");

        int pid = -1;
        String foundPkg = null;
        for (String pkg : GAME_PACKAGES) {
            int p = ProcessScanner.findPackage(pkg);
            if (p > 0) {
                pid = p;
                foundPkg = pkg;
                break;
            }
        }
        if (pid > 0) {
            sb.append("game: ").append(foundPkg).append(" pid=").append(pid);
        } else {
            sb.append("game: topilmadi (Virtual Space ichida och)");
        }
        statusText.setText(sb.toString());
    }

    private void launchGame() {
        PackageManager pm = getPackageManager();
        Intent intent = null;
        for (String pkg : GAME_PACKAGES) {
            intent = pm.getLaunchIntentForPackage(pkg);
            if (intent != null) break;
        }
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            if (checkOverlayPermission()) {
                startFloatingMenu();
            } else {
                requestOverlayPermission();
            }
        } else {
            Toast.makeText(this, getString(R.string.game_not_found), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(this);
        }
        return true;
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
            Toast.makeText(this, getString(R.string.overlay_permission), Toast.LENGTH_LONG).show();
        }
    }

    private void startFloatingMenu() {
        // re-attach injector to whatever game is visible in this space
        Intent esp = new Intent(this, ESPOverlayService.class);
        esp.setAction(ESPOverlayService.ACTION_ATTACH);
        startService(esp);

        Intent menu = new Intent(this, FloatingMenuService.class);
        startService(menu);
        Toast.makeText(this, "Menu + Injector ishga tushdi", Toast.LENGTH_SHORT).show();
        refreshStatus();
    }

    private void showGuide() {
        String msg =
                "VIRTUAL SPACE TARTIBI:\n\n" +
                "1. VirtualXposed / LSPosed + Parallel Space / Shelter o'rnat\n" +
                "2. Shu menyu APK ni Virtual Space ichiga o'rnat\n" +
                "3. Delta Force ni HAM Virtual Space ichiga o'rnat / klonla\n" +
                "4. Virtual Space ichidan ikkalasini ham och\n" +
                "5. Overlay ruxsat ber (Virtual Space ichida)\n" +
                "6. Show Floating Menu → ESP yoq\n\n" +
                "Muhim: ikkala app BIR XIL virtual muhitda bo'lishi shart.\n" +
                "Root yo'q — faqat bir xil sandbox ichida process ko'rinadi.";
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(this);
        b.setTitle("Virtual Space qo'llanma");
        b.setMessage(msg);
        b.setPositiveButton("OK", null);
        b.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (checkOverlayPermission()) {
                startFloatingMenu();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
            refreshStatus();
        }
    }
}
