package com.deltaforce.menu;

/**
 * JNI bridge to native external injector / memory reader.
 * Loads libdfinject.so which attaches to the game process
 * and exposes ESP entity / loot data.
 */
public final class NativeBridge {

    private static boolean loaded = false;
    private static boolean attachOk = false;

    static {
        try {
            System.loadLibrary("dfinject");
            loaded = true;
        } catch (UnsatisfiedLinkError e) {
            loaded = false;
        }
    }

    public static boolean isNativeLoaded() {
        return loaded;
    }

    public static boolean isAttached() {
        return attachOk;
    }

    /** Attach to target package. Returns true on success. */
    public static boolean attach(String packageName) {
        if (!loaded) return false;
        try {
            attachOk = nativeAttach(packageName);
        } catch (Throwable t) {
            attachOk = false;
        }
        return attachOk;
    }

    public static void detach() {
        if (!loaded) return;
        try {
            nativeDetach();
        } catch (Throwable ignored) {
        }
        attachOk = false;
    }

    /**
     * Fill float[] buffer with entity data.
     * Layout per entity (8 floats):
     *   [0] screenX  [1] screenY  [2] width  [3] height
     *   [4] health   [5] armor    [6] distance  [7] flags
     * flags bit0 = visible, bit1 = enemy
     * Returns entity count written.
     */
    public static int readEntities(float[] out, int maxCount) {
        if (!loaded || !attachOk) return 0;
        try {
            return nativeReadEntities(out, maxCount);
        } catch (Throwable t) {
            return 0;
        }
    }

    /**
     * Loot layout (6 floats):
     *   [0] screenX [1] screenY [2] tier [3] typeId [4] reserved [5] flags
     */
    public static int readLoot(float[] out, int maxCount) {
        if (!loaded || !attachOk) return 0;
        try {
            return nativeReadLoot(out, maxCount);
        } catch (Throwable t) {
            return 0;
        }
    }

    public static String getStatus() {
        if (!loaded) return "native not loaded";
        if (!attachOk) return "not attached";
        return "attached";
    }

    // --- native ---
    private static native boolean nativeAttach(String packageName);
    private static native void nativeDetach();
    private static native int nativeReadEntities(float[] out, int maxCount);
    private static native int nativeReadLoot(float[] out, int maxCount);
}
