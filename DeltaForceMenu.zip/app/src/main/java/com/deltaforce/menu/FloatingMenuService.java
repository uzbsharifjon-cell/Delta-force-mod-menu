
package com.deltaforce.menu;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.Toast;

public class FloatingMenuService extends Service {

    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private SharedPreferences prefs;

    private boolean isMinimized = false;
    private boolean isAdded = false;

    private int initialX, initialY;
    private float initialTouchX, initialTouchY;

    private ScrollView contentScroll;
    private View espContent, lootContent;

    private Switch switchEsp, switchArmor, switchHealth;
    private Switch switchDistance, switchWeapon;
    private Switch switchEspLoot;
    private Switch switchTier1, switchTier2, switchTier3;
    private Switch switchTier4, switchTier5, switchTier6;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        prefs = getSharedPreferences(
                "DeltaForceMenuPrefs",
                Context.MODE_PRIVATE
        );

        windowManager = (WindowManager)
                getSystemService(WINDOW_SERVICE);

        floatingView = LayoutInflater.from(this)
                .inflate(R.layout.floating_menu, null);

        setupLayoutParams();
        setupViews();
        loadSettings();
        setupListeners();

        try {
            windowManager.addView(floatingView, params);
            isAdded = true;
        } catch (Exception e) {
            Toast.makeText(this,
                    "Menyu ochilmadi",
                    Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }

        // start ESP canvas overlay (works with switches)
        Intent esp = new Intent(this, ESPOverlayService.class);
        esp.setAction(ESPOverlayService.ACTION_ATTACH);
        startService(esp);
    }

    private void setupLayoutParams() {

        int type;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            type = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 50;
        params.y = 200;
    }

    private void setupViews() {

        contentScroll = floatingView.findViewById(R.id.contentScroll);
        espContent = floatingView.findViewById(R.id.espContent);
        lootContent = floatingView.findViewById(R.id.lootContent);

        switchEsp = floatingView.findViewById(R.id.switchEsp);
        switchArmor = floatingView.findViewById(R.id.switchArmor);
        switchHealth = floatingView.findViewById(R.id.switchHealth);
        switchDistance = floatingView.findViewById(R.id.switchDistance);
        switchWeapon = floatingView.findViewById(R.id.switchWeapon);

        switchEspLoot = floatingView.findViewById(R.id.switchEspLoot);

        switchTier1 = floatingView.findViewById(R.id.switchTier1);
        switchTier2 = floatingView.findViewById(R.id.switchTier2);
        switchTier3 = floatingView.findViewById(R.id.switchTier3);
        switchTier4 = floatingView.findViewById(R.id.switchTier4);
        switchTier5 = floatingView.findViewById(R.id.switchTier5);
        switchTier6 = floatingView.findViewById(R.id.switchTier6);
    }

    private void loadSettings() {

        switchEsp.setChecked(prefs.getBoolean("esp_main", false));
        switchArmor.setChecked(prefs.getBoolean("esp_armor", true));
        switchHealth.setChecked(prefs.getBoolean("esp_health", true));
        switchDistance.setChecked(prefs.getBoolean("esp_distance", true));
        switchWeapon.setChecked(prefs.getBoolean("esp_weapon", true));

        switchEspLoot.setChecked(prefs.getBoolean("loot_main", false));

        switchTier1.setChecked(prefs.getBoolean("tier1", false));
        switchTier2.setChecked(prefs.getBoolean("tier2", false));
        switchTier3.setChecked(prefs.getBoolean("tier3", false));
        switchTier4.setChecked(prefs.getBoolean("tier4", false));
        switchTier5.setChecked(prefs.getBoolean("tier5", false));
        switchTier6.setChecked(prefs.getBoolean("tier6", false));

        espContent.setVisibility(View.GONE);
        lootContent.setVisibility(View.GONE);

        updateControls();
    }

    private void saveSettings() {

        prefs.edit()
                .putBoolean("esp_main", switchEsp.isChecked())
                .putBoolean("esp_armor", switchArmor.isChecked())
                .putBoolean("esp_health", switchHealth.isChecked())
                .putBoolean("esp_distance", switchDistance.isChecked())
                .putBoolean("esp_weapon", switchWeapon.isChecked())
                .putBoolean("loot_main", switchEspLoot.isChecked())
                .putBoolean("tier1", switchTier1.isChecked())
                .putBoolean("tier2", switchTier2.isChecked())
                .putBoolean("tier3", switchTier3.isChecked())
                .putBoolean("tier4", switchTier4.isChecked())
                .putBoolean("tier5", switchTier5.isChecked())
                .putBoolean("tier6", switchTier6.isChecked())
                .apply();

        // push live settings to ESP overlay
        Intent upd = new Intent(this, ESPOverlayService.class);
        upd.setAction(ESPOverlayService.ACTION_UPDATE);
        startService(upd);
    }

    private void updateControls() {

        boolean espEnabled = switchEsp.isChecked();
        boolean lootEnabled = switchEspLoot.isChecked();

        switchArmor.setEnabled(espEnabled);
        switchHealth.setEnabled(espEnabled);
        switchDistance.setEnabled(espEnabled);
        switchWeapon.setEnabled(espEnabled);

        switchTier1.setEnabled(lootEnabled);
        switchTier2.setEnabled(lootEnabled);
        switchTier3.setEnabled(lootEnabled);
        switchTier4.setEnabled(lootEnabled);
        switchTier5.setEnabled(lootEnabled);
        switchTier6.setEnabled(lootEnabled);

        espContent.setAlpha(espEnabled ? 1f : 0.45f);
        lootContent.setAlpha(lootEnabled ? 1f : 0.45f);
    }

    private void setupListeners() {

        View header = floatingView.findViewById(R.id.header);

        header.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX
                                + (int) (event.getRawX() - initialTouchX);

                        params.y = initialY
                                + (int) (event.getRawY() - initialTouchY);

                        if (isAdded) {
                            windowManager.updateViewLayout(
                                    floatingView, params);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        return true;
                }

                return false;
            }
        });

        ImageButton btnMinimize =
                floatingView.findViewById(R.id.btnMinimize);

        btnMinimize.setOnClickListener(v -> toggleMinimize());

        ImageButton btnClose =
                floatingView.findViewById(R.id.btnClose);

        btnClose.setOnClickListener(v -> stopSelf());

        floatingView.findViewById(R.id.espHeader)
                .setOnClickListener(v -> toggleSection(espContent));

        floatingView.findViewById(R.id.lootHeader)
                .setOnClickListener(v -> toggleSection(lootContent));

        switchEsp.setOnCheckedChangeListener((button, checked) -> {
            updateControls();
            saveSettings();
        });

        switchEspLoot.setOnCheckedChangeListener((button, checked) -> {
            updateControls();
            saveSettings();
        });

        Switch[] switches = {
                switchArmor, switchHealth, switchDistance,
                switchWeapon, switchTier1, switchTier2,
                switchTier3, switchTier4, switchTier5, switchTier6
        };

        for (Switch item : switches) {
            item.setOnCheckedChangeListener((button, checked) ->
                    saveSettings());
        }
    }

    private void toggleSection(View section) {

        if (section.getVisibility() == View.VISIBLE) {
            section.animate()
                    .alpha(0f)
                    .setDuration(180)
                    .withEndAction(() -> {
                        section.setVisibility(View.GONE);
                        section.setAlpha(1f);
                    });
        } else {
            section.setAlpha(0f);
            section.setVisibility(View.VISIBLE);

            section.animate()
                    .alpha(1f)
                    .setDuration(200)
                    .start();
        }
    }

    private void toggleMinimize() {

        isMinimized = !isMinimized;

        contentScroll.setVisibility(
                isMinimized ? View.GONE : View.VISIBLE
        );

        if (isAdded) {
            windowManager.updateViewLayout(floatingView, params);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {

        super.onDestroy();

        if (floatingView != null && isAdded) {
            try {
                windowManager.removeView(floatingView);
            } catch (Exception ignored) {
            }

            isAdded = false;
        }

        stopService(new Intent(this, ESPOverlayService.class));
    }
}
