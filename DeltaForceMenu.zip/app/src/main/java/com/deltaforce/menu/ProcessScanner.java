package com.deltaforce.menu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Java-side process enumerator. Used when native lib is absent
 * or to cross-check PID before attach.
 */
public final class ProcessScanner {

    public static class Proc {
        public final int pid;
        public final String cmdline;
        public Proc(int pid, String cmdline) {
            this.pid = pid;
            this.cmdline = cmdline;
        }
    }

    public static List<Proc> list() {
        List<Proc> out = new ArrayList<>();
        File proc = new File("/proc");
        File[] dirs = proc.listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (!d.isDirectory()) continue;
            String name = d.getName();
            if (!name.matches("\\d+")) continue;
            int pid;
            try {
                pid = Integer.parseInt(name);
            } catch (NumberFormatException e) {
                continue;
            }
            String cmd = readCmdline(pid);
            if (cmd == null || cmd.isEmpty()) continue;
            out.add(new Proc(pid, cmd));
        }
        return out;
    }

    public static int findPackage(String packageName) {
        if (packageName == null) return -1;
        for (Proc p : list()) {
            if (p.cmdline.equals(packageName)
                    || p.cmdline.startsWith(packageName + ":")
                    || p.cmdline.startsWith(packageName + " ")) {
                return p.pid;
            }
        }
        return -1;
    }

    private static String readCmdline(int pid) {
        File f = new File("/proc/" + pid + "/cmdline");
        if (!f.canRead()) return null;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line = br.readLine();
            if (line == null) return null;
            return line.replace('\0', ' ').trim();
        } catch (Exception e) {
            return null;
        }
    }
}
