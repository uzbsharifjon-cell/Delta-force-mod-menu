package com.deltaforce.menu;

/**
 * Pure Java demo injector — NDK kerak emas.
 * Harakatlanuvchi ESP box + loot marker beradi.
 */
public final class NativeBridge {

    private static boolean attached = false;
    private static long tick = 0;

    private static final int MAX_ENT = 8;
    private static final int MAX_LOOT = 10;
    private static final float[] ents = new float[MAX_ENT * 8];
    private static final float[] loots = new float[MAX_LOOT * 6];

    public static boolean isNativeLoaded() {
        return true;
    }

    public static boolean isAttached() {
        return attached;
    }

    public static boolean attach(String packageName) {
        attached = true;
        seed();
        return true;
    }

    public static void detach() {
        attached = false;
    }

    public static String getStatus() {
        return attached ? "attached (java-demo)" : "not attached";
    }

    public static int readEntities(float[] out, int maxCount) {
        if (!attached || out == null) return 0;
        tick++;
        update();
        int n = Math.min(maxCount, MAX_ENT);
        System.arraycopy(ents, 0, out, 0, Math.min(n * 8, out.length));
        return n;
    }

    public static int readLoot(float[] out, int maxCount) {
        if (!attached || out == null) return 0;
        int n = Math.min(maxCount, MAX_LOOT);
        System.arraycopy(loots, 0, out, 0, Math.min(n * 6, out.length));
        return n;
    }

    private static void seed() {
        for (int i = 0; i < MAX_ENT; i++) {
            int o = i * 8;
            ents[o] = 80 + i * 110;
            ents[o + 1] = 180 + (i % 3) * 160;
            ents[o + 2] = 70 + (i % 3) * 12;
            ents[o + 3] = 140 + (i % 4) * 18;
            ents[o + 4] = 40 + i * 8;
            ents[o + 5] = i % 6;
            ents[o + 6] = 25 + i * 14;
            ents[o + 7] = 3;
        }
        for (int i = 0; i < MAX_LOOT; i++) {
            int o = i * 6;
            loots[o] = 60 + i * 95;
            loots[o + 1] = 120 + (i % 5) * 110;
            loots[o + 2] = 1 + (i % 6);
            loots[o + 3] = i % 5;
            loots[o + 4] = 0;
            loots[o + 5] = 1;
        }
    }

    private static void update() {
        for (int i = 0; i < MAX_ENT; i++) {
            int o = i * 8;
            ents[o] += (float) Math.sin((tick + i * 17) * 0.04) * 1.6f;
            ents[o + 1] += (float) Math.cos((tick + i * 11) * 0.03) * 1.2f;
            if (ents[o] < 30) ents[o] = 30;
            if (ents[o] > 900) ents[o] = 900;
            if (ents[o + 1] < 80) ents[o + 1] = 80;
            if (ents[o + 1] > 1600) ents[o + 1] = 1600;
        }
    }
}
